#ifndef _input_h
#define _input_h

enum BUTTONS {
  B = 0x0001,
  Y = 0x0002,
  SELECT = 0x0004,
  START = 0x0008,
  UP = A0,
  DOWN = A2,
  LEFT = A3,
  RIGHT = A1,
  A = 8,
};

void input_setup();
bool input_up();
bool input_down();
bool input_left();
bool input_right();
bool input_fire();

#ifdef SNES_CONTROLLER
bool input_start();
void getControllerData(void);
#endif

#endif
